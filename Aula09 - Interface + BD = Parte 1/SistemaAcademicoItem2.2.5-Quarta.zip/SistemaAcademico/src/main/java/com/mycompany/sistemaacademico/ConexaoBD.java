package com.mycompany.sistemaacademico;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexaoBD {
    private static String host = "localhost";
    private static String porta = "3306";
    private static String db = "sistema_academico";
    private static String usuario = "root";
    private static String senha = "1234"; // imtdb
    
    public static Connection obterConexao() throws Exception{
        // jdbc:mysql://localhost:3306/sistema_academico
        String url = "jdbc:mysql://" + host + ":" + porta + "/" + db 
                + "?useTimezone=true&serverTimezone=UTC";
        return DriverManager.getConnection(url, usuario, senha);
    }  
}
