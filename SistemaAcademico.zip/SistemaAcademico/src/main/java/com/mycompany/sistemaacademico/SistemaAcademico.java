package com.mycompany.sistemaacademico;

public class SistemaAcademico {
    public static void main(String[] args) {
  
    }
}
