package com.mycompany.sistemaacademico;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
// import java.sql.*;

public class DAO {
    
    public boolean existe(Usuario usuario)
     throws Exception{
        String sql = 
          "SELECT * FROM tb_usuario" 
               + " WHERE nome = ? AND senha = ?"; 
        try(Connection conn = ConexaoBD.obterConexao();
            PreparedStatement ps = conn.prepareStatement(sql)
         ){
            // somente se as funções em try forem executadas
            // método para substituir os placeholders
            ps.setString(1, usuario.getNome());
            ps.setString(2, usuario.getSenha());
            
            //executar o comando sql, que seria o ps
            // receber a grid de resultado do comando
            // dentro do objeto rs e vamos verificar
            // se a grid esta vazia ou nao utilizando
            // o comando rs.next();
            try(ResultSet rs = ps.executeQuery()){
                return rs.next();
            }
        }
    }
    
    public Curso[] obterCursos() throws Exception{
        String sql = "SELECT * FROM tb_curso";
        
        try(Connection conn = ConexaoBD.obterConexao();
               PreparedStatement ps = conn.prepareStatement(sql, 
                       ResultSet.TYPE_SCROLL_INSENSITIVE,
                       ResultSet.CONCUR_READ_ONLY);
                       ResultSet rs = ps.executeQuery()           
        ){
           int totalDeCursos = rs.last() ? rs.getRow() : 0;
           Curso[] cursos = new Curso[totalDeCursos];
           
           rs.beforeFirst();
           int contador = 0;
           // percorrer toda a tabela de resultados do select (rs)
           while(rs.next()){ // enquanto ainda existir uma linha em rs
               // pega os valores nas colunas de cada curso cadastrado
               int id = rs.getInt("id");
               String nome = rs.getString("nome");
               String tipo = rs.getString("tipo");
               // criando um novo objeto com esse valores e incluindo na lista de cursos
               cursos[contador++] = new Curso(id, nome, tipo);
           }
            return cursos;
        }   
    }
}
