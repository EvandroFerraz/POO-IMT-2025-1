package com.mycompany.jogo;

public class Personagem {
    // atributos = variáveis que representam características
    private String nome;
    private int energia;
    private int fome;
    private int sono;
    
    // Construtor = método com o mesmo nome da classe
    // Serve para criar um objeto já com valores iniciais para seus atributos
    public Personagem(String nome, int energia, int fome, int sono){
        this.nome = nome;
        if(energia >= 0 && energia <= 10) // se estiver entre 0 e 10
            this.energia = energia;  
        if(fome >= 0 && fome <= 10)
            this.fome = fome;
        if(sono >= 0 && sono <= 10)
            this.sono = sono;
    }

    // métodos = funções que representam comportamentos
    void cacar(){
        if(energia >= 2){
           System.out.println(nome + " esta cacando!!");
           energia -= 2; // energia = energia - 2
           fome = Math.min (fome + 1, 10);
           sono = Math.min (sono + 1, 10);
           exibirEstado();       
        }else{ // energia < 2, não tem energia suficiente
            System.out.println(nome + " não tem energia!!");
        }
    }
    void comer(){
        if(fome >= 1){
            System.out.println(nome + " esta comendo!!");
            energia = Math.min(energia + 1, 10);
            fome -= 1; // fome = fome - 1
            exibirEstado();
        }else{ // fome < 1
            System.out.println(nome + " esta sem fome!!");
        }
    }   
    void dormir(){
        if(sono >= 1){
           System.out.println(nome + " esta dormindo!!");
           // operador ternário
           energia = energia + 1 <= 10 ? energia + 1 : 10;
           sono -= 1; // sono = sono - 1
           exibirEstado();
        }else{ // sono < 1
            System.out.println(nome + " esta sem sono!!");
        }  
    }
    
    // estado se refere ao valor atual dos atributos
    void exibirEstado(){
        System.out.println("Energia: " + energia + "\n Fome: " + fome 
            + "\n Sono: " + sono);
    }
}
