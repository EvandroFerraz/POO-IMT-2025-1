package com.mycompany.jogo;

public class Jogo {
    public static void main(String[] args) throws InterruptedException{
        Personagem cacador = new Personagem("Joao", 10, 0, 0);
        // cacador, nome = "Joao", fome = sono = 0; energia = 10
        
        while(true){ //loop infinito
           cacador.cacar();
           cacador.dormir();
           cacador.comer();
           System.out.println("====================");
           Thread.sleep(4000);
        }
    }
}
