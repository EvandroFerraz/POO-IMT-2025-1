package com.mycompany.sistemaacademico;

public class Curso {
    // atributos
    private int id;
    private String nome;
    private String tipo;
    
    // Inicia os 3 atributos
    public Curso(int id, String nome, String tipo) {
        this.id = id;
        this.nome = nome;
        this.tipo = tipo;
    }
    
    // Iniciar somente o nome e o tipo
    public Curso(String nome, String tipo){
        this.nome = nome;
        this.tipo = tipo;
    }
    
    // getters gerados automaticamente
    public int getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getTipo() {
        return tipo;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    
    // sobrescrever o método toString()
    @Override
    public String toString(){
        return this.nome;
    }
}
