package com.mycompany.sistemaacademico;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConexaoBD {
    private static String host = "teste-poo-2204.l.aivencloud.com";
    private static String porta = "25407";
    private static String db = "sistema_academico";
    private static String usuario = "avnadmin";
    private static String senha = "AVNS_7UskuclPufRvoyRWMWd";
    
    public static Connection obterConexao() throws Exception{
        //criar a string de conexão
        // jdbc:mysql://localhost:3306/sistema_academico
        String url = "jdbc:mysql://" + host + ":" + porta + "/" + db 
                + "?useTimezone=true&serverTimezone=UTC";
        
        return DriverManager.getConnection(url,usuario,senha);
    }
}
