package com.mycompany.helloswingtela;

import java.awt.Container;
import javax.swing.*;

public class HelloSwingTela {
    
    public static void criarTela(){
        JFrame tela = new JFrame("Hello Swing!!");
        tela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // construir um JLabel
        JLabel helloSwingLabel = new JLabel("Hello Swing");
        // cria painel de conteúdo
        Container painelDeConteudo = tela.getContentPane();
        painelDeConteudo.add(helloSwingLabel);
        // tornar a tela visivel para o usuário
        tela.setVisible(true);
        tela.pack();
    }   
    public static void main(String[] args) {
        //SwingUtilities.invokeLater(() -> {
            criarTela();
        //});
    }
}
