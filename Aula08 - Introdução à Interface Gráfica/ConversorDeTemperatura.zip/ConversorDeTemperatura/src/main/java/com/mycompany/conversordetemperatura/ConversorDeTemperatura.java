package com.mycompany.conversordetemperatura;

import java.awt.*;
import javax.swing.*; // * = todas

public class ConversorDeTemperatura {
    
    public static void criarTela(){
        JFrame tela = new JFrame("Conversor");
        // criação do campo de texto
        JTextField celsiusTextField = new JTextField(10);
        JLabel celsiusLabel = new JLabel("\u00B0C");
        JButton convertButton = new JButton("Converter");
        JLabel valorConvertidoLabel = new JLabel("");
        
        Container painelDeConteudo = tela.getContentPane();
        
        painelDeConteudo.setLayout(new GridLayout(2, 4, 2, 4));
        painelDeConteudo.add(celsiusTextField); // 1 linha da 1 coluna
        painelDeConteudo.add(celsiusLabel); // 2 linha da 1 coluna
        painelDeConteudo.add(convertButton); // 1 linda da 2 coluna 
        painelDeConteudo.add(valorConvertidoLabel); // 2 linha da 2 coluna
        
        convertButton.addActionListener((e) -> {
            // entrada da dados
            double celsius = Double.parseDouble(
                    celsiusTextField.getText()
            );
            // processamento
            double fahrenheit = celsius / 5 * 9 + 32;
            // saída de dados
            valorConvertidoLabel.setText(
                String.format("%.2f\u00B0F", fahrenheit)
            );
        });  
        // ajustar a largura e a altura de acordo com o numero de elementos
        tela.pack();
        // centralizar
        tela.setLocationRelativeTo(null);
        tela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        tela.setVisible(true);
    }
    
    public static void main(String[] args) {
        criarTela();
    }
}
