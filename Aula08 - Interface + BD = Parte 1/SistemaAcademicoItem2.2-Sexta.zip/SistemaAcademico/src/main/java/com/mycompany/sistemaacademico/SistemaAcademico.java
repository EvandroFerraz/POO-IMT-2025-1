/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistemaacademico;

/**
 *
 * @author evandro.ferraz
 */
public class SistemaAcademico {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
