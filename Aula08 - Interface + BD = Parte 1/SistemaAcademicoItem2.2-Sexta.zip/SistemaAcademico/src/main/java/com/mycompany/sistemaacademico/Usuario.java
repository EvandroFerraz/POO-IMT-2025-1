
package com.mycompany.sistemaacademico;

public class Usuario {
    // atributos
    private String nome;
    private String senha;
    
    // construtor - cria um objeto da classe
    public Usuario(String nome, String senha){
        this.nome = nome;
        this.senha = senha;
    }
    // Usuario usuario = new Usuario("joao","1234");
    // usuario.setSenha("123");
    
    // getter - método de consulta
    public String getNome(){
        return nome;
    }
    public String getSenha(){
        return senha;
    }
    //"O nome do joao é: " + joao.getNome();
    
    //setters - métodos de modificação
    public void setNome(String nome){
        this.nome = nome;
    }
    public void setSenha(String novaSenha){
        senha = novaSenha;
    }
    
    
    
    
    
    
    
}
